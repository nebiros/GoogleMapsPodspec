#import "SDKDemos/Samples/Samples.h"

@interface Samples (Places)

+ (NSArray *)placesDemos;

@end
