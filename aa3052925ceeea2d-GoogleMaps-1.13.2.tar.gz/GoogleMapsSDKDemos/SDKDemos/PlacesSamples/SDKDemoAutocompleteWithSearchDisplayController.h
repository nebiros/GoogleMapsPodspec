#import <UIKit/UIKit.h>

// A demo showing how to use GMSAutocompleteViewController with a UISearchDisplayController.
@interface SDKDemoAutocompleteWithSearchDisplayController : UIViewController

@end
