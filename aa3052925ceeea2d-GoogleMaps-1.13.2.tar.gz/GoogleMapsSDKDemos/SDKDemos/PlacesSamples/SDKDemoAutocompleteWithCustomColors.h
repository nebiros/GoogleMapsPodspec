#import <UIKit/UIKit.h>

// SDK Demo showing how to customise colors in the full-screen Autocomplete Widget.
@interface SDKDemoAutocompleteWithCustomColors : UIViewController

@end
