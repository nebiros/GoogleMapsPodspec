#import <UIKit/UIKit.h>

// Demo showing full-screen use of GMSAutocompleteViewController.
@interface SDKDemoAutocompleteWidgetViewController : UIViewController <
    UITableViewDelegate, UITableViewDataSource>
@end
