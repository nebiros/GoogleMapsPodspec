#import <UIKit/UIKit.h>

@interface MapZoomViewController : UIViewController

@end
