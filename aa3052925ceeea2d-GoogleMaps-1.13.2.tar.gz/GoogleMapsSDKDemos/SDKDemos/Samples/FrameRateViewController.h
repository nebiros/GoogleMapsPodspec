#import <UIKit/UIKit.h>

@interface FrameRateViewController : UIViewController

@end
